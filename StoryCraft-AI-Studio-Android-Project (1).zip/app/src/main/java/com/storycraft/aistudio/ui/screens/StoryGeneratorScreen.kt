package com.storycraft.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.storycraft.aistudio.data.ai.GeminiStoryService
import com.storycraft.aistudio.model.*
import com.storycraft.aistudio.ui.theme.*
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun StoryGeneratorScreen(
    characters: List<Character>,
    language: AppLanguage,
    onSaveProject: (StoryProject) -> Unit,
    onCopy: (String) -> Unit,
    aiService: GeminiStoryService
) {
    val coroutineScope = rememberCoroutineScope()

    var title by remember { mutableStateOf("The Crimson Crown") }
    var genre by remember { mutableStateOf("Historical Royal Intrigue") }
    var tone by remember { mutableStateOf("Dark, Poetic & Suspenseful") }
    var premise by remember { mutableStateOf("A royal heir returns incognito to reclaim an empire taken by traitorous advisors.") }
    var selectedEpisodeCount by remember { mutableStateOf(10) }
    var selectedCharacterIds by remember { mutableStateOf(characters.map { it.id }.toSet()) }

    var isGenerating by remember { mutableStateOf(false) }
    var generatedEpisodes by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var saveSuccessMessage by remember { mutableStateOf(false) }

    val episodeOptions = listOf(5, 10, 20, 30, 40)
    val genres = listOf("Cyberpunk Neo-Noir", "Historical Royal Intrigue", "Sci-Fi Space Opera", "Urdu/Hindi Mystery Drama", "Supernatural Mythic")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Multi-Episode AI Story Generator",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Generate comprehensive multi-episode series (5 to 40 episodes) with Character Lock consistency.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        // Configuration Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Story Title") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAccent,
                            unfocusedBorderColor = SurfaceBorder
                        )
                    )

                    OutlinedTextField(
                        value = premise,
                        onValueChange = { premise = it },
                        label = { Text("Core Premise & Conflict") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAccent,
                            unfocusedBorderColor = SurfaceBorder
                        )
                    )

                    // Episode Count Selector (5, 10, 20, 30, 40)
                    Text("Select Season Length (Episodes):", style = MaterialTheme.typography.titleMedium, color = GoldLight)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        episodeOptions.forEach { count ->
                            val isSelected = selectedEpisodeCount == count
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) PurpleDark else SurfaceElevated)
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) GoldAccent else SurfaceBorder,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable { selectedEpisodeCount = count }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$count Ep",
                                    color = if (isSelected) GoldAccent else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    // Character Lock Injection Preview
                    Text("Locked Characters for this Series:", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    if (characters.isEmpty()) {
                        Text("No characters locked yet. Visit the Character Lock tab to configure consistency.", color = TextMuted, fontSize = 12.sp)
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            characters.forEach { char ->
                                val isChecked = selectedCharacterIds.contains(char.id)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(SurfaceElevated)
                                        .clickable {
                                            selectedCharacterIds = if (isChecked) selectedCharacterIds - char.id else selectedCharacterIds + char.id
                                        }
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            selectedCharacterIds = if (checked) selectedCharacterIds + char.id else selectedCharacterIds - char.id
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = GoldAccent)
                                    )
                                    Column {
                                        Text(char.name, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 14.sp)
                                        Text("${char.role} • ${char.appearance.take(40)}...", color = TextSecondary, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            isGenerating = true
                            saveSuccessMessage = false
                            coroutineScope.launch {
                                val activeChars = characters.filter { selectedCharacterIds.contains(it.id) }
                                val result = aiService.generateStory(
                                    title = title,
                                    genre = genre,
                                    tone = tone,
                                    premise = premise,
                                    episodeCount = selectedEpisodeCount,
                                    language = language,
                                    lockedCharacters = activeChars
                                )
                                generatedEpisodes = result
                                isGenerating = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                        enabled = !isGenerating
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = BgBlack)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generating $selectedEpisodeCount Episodes...", color = BgBlack)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = BgBlack)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate $selectedEpisodeCount Episodes", color = BgBlack, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Generated Results Header & Actions
        if (generatedEpisodes.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Season Outline (${generatedEpisodes.size} Episodes)",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = {
                                val fullText = generatedEpisodes.joinToString("\n\n") { ep ->
                                    "EPISODE ${ep.number}: ${ep.title}\nLogline: ${ep.logline}\nSynopsis: ${ep.synopsis}\nKey Conflict: ${ep.keyConflict}\nCharacter Arc: ${ep.characterArcs}\nClimax: ${ep.climax}"
                                }
                                onCopy(fullText)
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy All", tint = GoldAccent)
                        }
                        Button(
                            onClick = {
                                val activeChars = characters.filter { selectedCharacterIds.contains(it.id) }
                                val proj = StoryProject(
                                    id = UUID.randomUUID().toString(),
                                    title = title,
                                    genre = genre,
                                    tone = tone,
                                    premise = premise,
                                    language = language,
                                    targetEpisodes = selectedEpisodeCount,
                                    characters = activeChars,
                                    episodes = generatedEpisodes
                                )
                                onSaveProject(proj)
                                saveSuccessMessage = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Save")
                        }
                    }
                }
                if (saveSuccessMessage) {
                    Text("✓ Project saved to local storage!", color = SuccessGreen, fontSize = 13.sp)
                }
            }

            // Episode Cards List
            items(generatedEpisodes) { episode ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = episode.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = GoldAccent
                            )
                            IconButton(
                                onClick = {
                                    val text = "${episode.title}\nLogline: ${episode.logline}\nSynopsis: ${episode.synopsis}\nConflict: ${episode.keyConflict}\nClimax: ${episode.climax}"
                                    onCopy(text)
                                }
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy Episode", tint = TextSecondary, modifier = Modifier.size(18.dp))
                            }
                        }
                        Text(text = episode.logline, color = TextPrimary, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                        Text(text = episode.synopsis, color = TextSecondary, fontSize = 13.sp)
                        Divider(color = SurfaceBorder, modifier = Modifier.padding(vertical = 4.dp))
                        Row {
                            Text("Conflict: ", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(episode.keyConflict, color = TextSecondary, fontSize = 12.sp)
                        }
                        Row {
                            Text("Climax: ", color = PurpleLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(episode.climax, color = TextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
