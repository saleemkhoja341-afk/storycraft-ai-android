package com.storycraft.aistudio

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.storycraft.aistudio.data.ProjectRepository
import com.storycraft.aistudio.data.ai.GeminiStoryService
import com.storycraft.aistudio.model.*
import com.storycraft.aistudio.ui.screens.*
import com.storycraft.aistudio.ui.theme.*

enum class Screen(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    GENERATOR("AI Generator", Icons.Default.AutoAwesome),
    CHARACTERS("Character Lock", Icons.Default.People),
    DIALOGUE("Dialogue", Icons.Default.RecordVoiceOver),
    GOOGLE_FLOW("Google Flow", Icons.Default.Videocam),
    PROJECTS("Projects", Icons.Default.Folder),
    SETTINGS("Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private lateinit var repository: ProjectRepository
    private lateinit var aiService: GeminiStoryService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = ProjectRepository(this)
        aiService = GeminiStoryService()

        setContent {
            StoryCraftAIStudioTheme {
                var currentScreen by remember { mutableStateOf(Screen.HOME) }
                val currentLanguage by repository.currentLanguage.collectAsState()
                val projects by repository.projects.collectAsState()
                val lockedCharacters by repository.lockedCharacters.collectAsState()

                fun copyToClipboard(text: String, label: String = "StoryCraft") {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText(label, text)
                    clipboard.setPrimaryClip(clip)
                    Toast.makeText(this, "Copied to clipboard!", Toast.LENGTH_SHORT).show()
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Scaffold(
                        bottomBar = {
                            NavigationBar(
                                containerColor = SurfaceDark,
                                contentColor = GoldAccent
                            ) {
                                Screen.values().forEach { screen ->
                                    NavigationBarItem(
                                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                                        label = { Text(screen.title) },
                                        selected = currentScreen == screen,
                                        onClick = { currentScreen = screen },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = GoldAccent,
                                            selectedTextColor = GoldAccent,
                                            indicatorColor = PurpleDark,
                                            unselectedIconColor = TextSecondary,
                                            unselectedTextColor = TextSecondary
                                        )
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                                .background(BgBlack)
                        ) {
                            when (currentScreen) {
                                Screen.HOME -> HomeScreen(
                                    projects = projects,
                                    characters = lockedCharacters,
                                    onNavigateTo = { currentScreen = it },
                                    onCopy = { copyToClipboard(it) }
                                )
                                Screen.GENERATOR -> StoryGeneratorScreen(
                                    characters = lockedCharacters,
                                    language = currentLanguage,
                                    onSaveProject = { repository.saveProject(it) },
                                    onCopy = { copyToClipboard(it) },
                                    aiService = aiService
                                )
                                Screen.CHARACTERS -> CharacterLockScreen(
                                    characters = lockedCharacters,
                                    onSaveCharacter = { repository.saveCharacter(it) },
                                    onDeleteCharacter = { repository.deleteCharacter(it) },
                                    onCopy = { copyToClipboard(it) }
                                )
                                Screen.DIALOGUE -> DialogueGeneratorScreen(
                                    characters = lockedCharacters,
                                    language = currentLanguage,
                                    onCopy = { copyToClipboard(it) },
                                    aiService = aiService
                                )
                                Screen.GOOGLE_FLOW -> GoogleFlowScreen(
                                    characters = lockedCharacters,
                                    onCopy = { copyToClipboard(it) },
                                    aiService = aiService
                                )
                                Screen.PROJECTS -> ProjectsScreen(
                                    projects = projects,
                                    onDeleteProject = { repository.deleteProject(it) },
                                    onExportProject = { project ->
                                        val text = repository.exportProjectAsPlainText(project)
                                        copyToClipboard(text, "Exported Project")
                                        Toast.makeText(this@MainActivity, "Project exported and copied to clipboard!", Toast.LENGTH_LONG).show()
                                    },
                                    onCopy = { copyToClipboard(it) }
                                )
                                Screen.SETTINGS -> SettingsScreen(
                                    currentLanguage = currentLanguage,
                                    onLanguageChange = { repository.setLanguage(it) },
                                    onResetData = { repository.resetAllData() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
