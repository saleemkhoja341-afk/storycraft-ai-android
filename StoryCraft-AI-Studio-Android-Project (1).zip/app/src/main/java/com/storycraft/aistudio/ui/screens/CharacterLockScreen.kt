package com.storycraft.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.storycraft.aistudio.model.Character
import com.storycraft.aistudio.ui.theme.*
import java.util.UUID

@Composable
fun CharacterLockScreen(
    characters: List<Character>,
    onSaveCharacter: (Character) -> Unit,
    onDeleteCharacter: (String) -> Unit,
    onCopy: (String) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var editingChar by remember { mutableStateOf<Character?>(null) }

    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("") }
    var ageText by remember { mutableStateOf("28") }
    var appearance by remember { mutableStateOf("") }
    var clothes by remember { mutableStateOf("") }
    var personality by remember { mutableStateOf("") }
    var flaw by remember { mutableStateOf("") }

    fun openEdit(char: Character?) {
        editingChar = char
        if (char != null) {
            name = char.name
            role = char.role
            ageText = char.age.toString()
            appearance = char.appearance
            clothes = char.clothes
            personality = char.personality
            flaw = char.flawAndMotivation
        } else {
            name = ""
            role = "Protagonist"
            ageText = "28"
            appearance = "Piercing green eyes, sharp facial structure, short dark textured hair"
            clothes = "Embroidered black velvet coat with subtle gold cuffs and linen tunic"
            personality = "Stoic, fiercely loyal, speaks in concise poetic cadence"
            flaw = "Tormented by a past failure, finds it hard to trust companions"
        }
        showDialog = true
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Character Lock Studio",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Lock appearance, clothes, and psychology so every episode retains absolute consistency.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
                Button(
                    onClick = { openEdit(null) },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = BgBlack)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New", color = BgBlack, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (characters.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No locked characters yet. Click 'New' above to create one.", color = TextSecondary)
                    }
                }
            }
        } else {
            items(characters) { char ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(PurpleDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(18.dp))
                                }
                                Column {
                                    Text(char.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text("${char.role} • Age ${char.age}", color = GoldLight, fontSize = 12.sp)
                                }
                            }
                            Row {
                                IconButton(onClick = {
                                    val text = "CHARACTER: ${char.name} (${char.role}, Age ${char.age})\nAppearance: ${char.appearance}\nClothes: ${char.clothes}\nPersonality: ${char.personality}\nFlaw/Motivation: ${char.flawAndMotivation}"
                                    onCopy(text)
                                }) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextSecondary, modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { openEdit(char) }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onDeleteCharacter(char.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerRed, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Divider(color = SurfaceBorder)

                        Text("Appearance & Features:", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(char.appearance, color = TextPrimary, fontSize = 13.sp)

                        Text("Wardrobe & Clothes:", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(char.clothes, color = TextPrimary, fontSize = 13.sp)

                        Text("Personality & Psychology:", color = PurpleLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(char.personality, color = TextSecondary, fontSize = 13.sp)

                        Text("Flaw & Inner Drive:", color = PurpleLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(char.flawAndMotivation, color = TextSecondary, fontSize = 13.sp)
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Text(
                    if (editingChar == null) "Lock New Character" else "Edit Locked Character",
                    color = GoldLight,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Character Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = role,
                                onValueChange = { role = it },
                                label = { Text("Role") },
                                modifier = Modifier.weight(2f)
                            )
                            OutlinedTextField(
                                value = ageText,
                                onValueChange = { ageText = it },
                                label = { Text("Age") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = appearance,
                            onValueChange = { appearance = it },
                            label = { Text("Appearance (Face, Hair, Height, Eyes)") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = clothes,
                            onValueChange = { clothes = it },
                            label = { Text("Signature Wardrobe & Costumes") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = personality,
                            onValueChange = { personality = it },
                            label = { Text("Personality & Speech Cadence") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = flaw,
                            onValueChange = { flaw = it },
                            label = { Text("Flaw & Secret Desire") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedAge = ageText.toIntOrNull() ?: 25
                        val char = Character(
                            id = editingChar?.id ?: UUID.randomUUID().toString(),
                            name = name.ifBlank { "Unknown Character" },
                            age = parsedAge,
                            role = role.ifBlank { "Protagonist" },
                            appearance = appearance,
                            clothes = clothes,
                            personality = personality,
                            flawAndMotivation = flaw,
                            isLocked = true
                        )
                        onSaveCharacter(char)
                        showDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
                ) {
                    Text("Save & Lock", color = BgBlack, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = SurfaceElevated
        )
    }
}
