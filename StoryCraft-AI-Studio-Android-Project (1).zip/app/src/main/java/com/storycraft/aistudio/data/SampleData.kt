package com.storycraft.aistudio.data

import com.storycraft.aistudio.model.*

object SampleData {
    val sampleCharacters = listOf(
        Character(
            id = "char-1",
            name = "Zain Al-Mulk (زین الملک)",
            age = 34,
            role = "Cyber-Poet Detective",
            appearance = "Tall, sharp jawline, silver-threaded cybernetic left eye, jet-black hair with temple streaks",
            clothes = "Midnight-blue embroidered sherwani with gold fiber wiring, black tactical trousers, leather gloves",
            personality = "Melancholic, razor-sharp intellect, quotes classical Ghalib couplets during crime analysis",
            flawAndMotivation = "Haunted by the disappearance of his sister in the Under-City; driven by relentless justice",
            isLocked = true
        ),
        Character(
            id = "char-2",
            name = "Aanya Verma (आन्या वर्मा)",
            age = 28,
            role = "Neural Architect",
            appearance = "Striking hazel eyes, amber complexion, braided hair woven with copper signal threads",
            clothes = "Crimson silk trench coat with luminescent gold trim, high-collar neural dampener",
            personality = "Unapologetically audacious, hyper-calculated, protective of historical artifacts",
            flawAndMotivation = "Suffers from neural overload flashes; seeks to decrypt the Magadha Quantum Codex",
            isLocked = true
        ),
        Character(
            id = "char-3",
            name = "Commander Tarek (کمانڈر طارق)",
            age = 48,
            role = "Enforcer of the High Citadel",
            appearance = "Burly build, scarred right brow, obsidian cybernetic prosthetic arm with gold inlays",
            clothes = "Matte-black armor plate with imperial crest, deep violet cape",
            personality = "Authoritarian, unwavering loyalty to the Council, cold calculated cadence",
            flawAndMotivation = "Secretly conflicted between duty and family bloodlines",
            isLocked = true
        )
    )

    val sampleProjects: List<StoryProject> = listOf(
        StoryProject(
            id = "proj-lahore-2099",
            title = "The Shadow of Lahore 2099 (سایہ لاہور ۲۰۹۹)",
            genre = "Cyberpunk Neo-Noir",
            tone = "Atmospheric, Poetic, High-Stakes",
            premise = "In rain-soaked 2099 Lahore, neon minarets glow above the smog as detective Zain Al-Mulk investigates the assassination of the chief synthetic memory curator.",
            language = AppLanguage.URDU,
            targetEpisodes = 10,
            characters = sampleCharacters.take(2),
            episodes = (1..10).map { epNum ->
                Episode(
                    number = epNum,
                    title = when (epNum) {
                        1 -> "قسط ۱: راوی کی راکھ (The Ash of Ravi)"
                        2 -> "قسط ۲: شیش محل کا عکس (Mirror of Sheesh Mahal)"
                        3 -> "قسط ۳: سائے اور سراب (Shadows and Mirages)"
                        4 -> "قسط ۴: ڈیٹا کا دریا (River of Data)"
                        5 -> "قسط ۵: نصف شب کی گھنٹی (Midnight Toll)"
                        6 -> "قسط ۶: زنگ آلود یادیں (Corroded Memories)"
                        7 -> "قسط ۷: فصیل کے پار (Beyond the Ramparts)"
                        8 -> "قسط ۸: غدار کا چہرہ (Face of the Traitor)"
                        9 -> "قسط ۹: طوفان سے پہلے (Before the Storm)"
                        else -> "قسط ۱۰: حتمی فیصلہ (The Final Reckoning)"
                    },
                    logline = "Zain follows encrypted memory fragments through the neon alleyways of Old Anarkali while Aanya reveals a secret conspiracy.",
                    synopsis = "Episode $epNum deepens the mystery. Zain interrogates synthetic memory brokers while Aanya decodes the stolen bio-chip. The rain-drenched rooftop confrontation changes the balance of power across Lahore Citadel.",
                    keyConflict = "Corporate enforcers versus Zain's clandestine network; conflicting loyalty between truth and peace.",
                    characterArcs = "Zain discovers that the assassin used his own childhood frequency; Aanya risks neural corruption to save him.",
                    climax = "A high-tension standoff in the neon-lit minaret balcony during a thunderous monsoon storm."
                )
            },
            dialogues = listOf(
                DialogueLine(
                    id = "dlg-1",
                    speaker = "Zain Al-Mulk",
                    emotion = "گہرے اضطراب کے ساتھ (Melancholic resolve)",
                    textEnglish = "Memory is not a code you can delete. It bleeds into the walls of this city.",
                    textUrdu = "یادداشت کوئی ایسا کوڈ نہیں جسے تم مٹا سکو۔ یہ اس شہر کی دیواروں میں لہو بن کر دوڑتی ہے۔",
                    textHindi = "स्मृति कोई ऐसा कोड नहीं जिसे तुम मिटा सको। यह इस शहर की दीवारों में बहती है।",
                    deliveryNote = "Spoken while standing on the rooftop in pouring rain, looking over the neon grid."
                ),
                DialogueLine(
                    id = "dlg-2",
                    speaker = "Aanya Verma",
                    emotion = "دھیمی اور سنجیدہ آواز (Cautious whisper)",
                    textEnglish = "If you unlock the tenth gate, there will be no turning back, Zain.",
                    textUrdu = "اگر تم نے دسواں دروازہ کھول دیا تو واپسی کا کوئی راستہ نہیں رہے گا، زین۔",
                    textHindi = "अगर तुमने दसवां दरवाज़ा खोल दिया, तो लौटने का कोई रास्ता नहीं बचेगा, ज़ैन।",
                    deliveryNote = "Hands trembling over the quantum console interface."
                )
            ),
            googleFlowPrompts = listOf(
                GoogleFlowPrompt(
                    id = "gf-1",
                    sceneNumber = 1,
                    title = "Monsoon Descent into Lahore 2099",
                    cameraAngle = "Slow 4K anamorphic low-angle tracking shot, 35mm lens, camera pushing forward at eye level",
                    lighting = "Deep violet volumetric rain haze pierced by intense amber neon signage and wet tarmac reflections",
                    environment = "Narrow cyberpunk alley of Lahore with historical Mughal archways overlaid with holographic Arabic calligraphy",
                    characterAction = "Zain Al-Mulk walks through heavy rain, his midnight-blue sherwani woven with gold luminescent circuitry, smoke curling from his lips",
                    audioAtmosphere = "Heavy rhythmic rainfall, distant electronic azan echo, synth drone bass rumble",
                    consolidatedPrompt = "Cinematic 8k, low angle 35mm anamorphic camera gliding forward through rain-drenched cybernetic Lahore street. Zain Al-Mulk walking towards camera in midnight-blue sherwani with glowing gold trim, neon Urdu holograms reflecting in puddle surfaces, moody atmospheric deep purple and gold lighting."
                )
            )
        ),
        StoryProject(
            id = "proj-magadha-embers",
            title = "Embers of Magadha (मगध के अंगारे)",
            genre = "Historical Mythic Intrigue",
            tone = "Heroic, Royal, Dramatic",
            premise = "In the ancient royal court of Magadha, a royal spymaster uncovers a conspiracy that threatens to ignite war between neighboring kingdoms.",
            language = AppLanguage.HINDI,
            targetEpisodes = 5,
            characters = sampleCharacters.take(3),
            episodes = (1..5).map { epNum ->
                Episode(
                    number = epNum,
                    title = "एपिसोड $epNum: " + when(epNum) {
                        1 -> "राजदरबार का षड्यंत्र (Conspiracy at Court)"
                        2 -> "गुप्तचर की परीक्षा (Trial of the Spymaster)"
                        3 -> "अग्नि की शपथ (Oath of Fire)"
                        4 -> "विश्वासघात की रात (Night of Betrayal)"
                        else -> "सिंहासन का युद्ध (War for the Throne)"
                    },
                    logline = "Ancient secrets in the stone halls of Pataliputra as alliances shatter under midnight skies.",
                    synopsis = "The emperor's decree summons the warriors. A secret cipher found on an assassinated emissary reveals a betrayal deep inside the council chambers.",
                    keyConflict = "Royal protocol vs righteous justice.",
                    characterArcs = "Aanya deciphers the ancient seal while Commander Tarek prepares the fortress defenses.",
                    climax = "The torch-lit duel in the royal hall of marble."
                )
            }
        )
    )
}
