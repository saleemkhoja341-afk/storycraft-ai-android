package com.storycraft.aistudio.ui.theme

import androidx.compose.ui.graphics.Color

val BgBlack = Color(0xFF0A0714)
val SurfaceDark = Color(0xFF150F26)
val SurfaceElevated = Color(0xFF1F1538)
val SurfaceBorder = Color(0xFF3B2166)

val PurplePrimary = Color(0xFF7C3AED)
val PurpleDark = Color(0xFF4C1D95)
val PurpleLight = Color(0xFFA78BFA)

val GoldAccent = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFBBF24)
val GoldDark = Color(0xFFB45309)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val SuccessGreen = Color(0xFF10B981)
val DangerRed = Color(0xFFEF4444)
