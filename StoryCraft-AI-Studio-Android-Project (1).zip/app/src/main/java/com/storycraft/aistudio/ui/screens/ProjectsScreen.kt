package com.storycraft.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.storycraft.aistudio.model.StoryProject
import com.storycraft.aistudio.ui.theme.*

@Composable
fun ProjectsScreen(
    projects: List<StoryProject>,
    onDeleteProject: (String) -> Unit,
    onExportProject: (StoryProject) -> Unit,
    onCopy: (String) -> Unit
) {
    var expandedProjectId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Saved Projects & Archives",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Manage your saved series, re-open episode drafts, export complete scripts as TXT files, and copy prompt sets.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        if (projects.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No saved projects found. Generate a story to save your first project.", color = TextSecondary)
                    }
                }
            }
        } else {
            items(projects) { project ->
                val isExpanded = expandedProjectId == project.id

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = project.title,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldLight
                                )
                                Text(
                                    text = "${project.genre} • ${project.episodes.size} Episodes • ${project.language.displayName}",
                                    color = PurpleLight,
                                    fontSize = 12.sp
                                )
                            }
                            IconButton(onClick = { onDeleteProject(project.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerRed)
                            }
                        }

                        Text(text = project.premise, color = TextSecondary, fontSize = 13.sp)

                        // Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onExportProject(project) },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = null, tint = BgBlack, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Export TXT", color = BgBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    expandedProjectId = if (isExpanded) null else project.id
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isExpanded) "Hide Episodes" else "View Episodes", color = TextPrimary, fontSize = 12.sp)
                            }
                        }

                        // Expanded Episodes List
                        if (isExpanded) {
                            Divider(color = SurfaceBorder, modifier = Modifier.padding(vertical = 4.dp))
                            Text("Episode List (${project.episodes.size}):", color = GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

                            project.episodes.forEach { ep ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(SurfaceElevated)
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(ep.title, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 13.sp)
                                        IconButton(onClick = {
                                            onCopy("${ep.title}\nLogline: ${ep.logline}\nSynopsis: ${ep.synopsis}")
                                        }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextSecondary, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    Text(ep.logline, color = TextSecondary, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
