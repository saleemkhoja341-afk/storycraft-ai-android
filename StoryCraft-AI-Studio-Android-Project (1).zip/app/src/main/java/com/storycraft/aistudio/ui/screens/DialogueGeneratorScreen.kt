package com.storycraft.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.storycraft.aistudio.data.ai.GeminiStoryService
import com.storycraft.aistudio.model.*
import com.storycraft.aistudio.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun DialogueGeneratorScreen(
    characters: List<Character>,
    language: AppLanguage,
    onCopy: (String) -> Unit,
    aiService: GeminiStoryService
) {
    val coroutineScope = rememberCoroutineScope()

    var sceneContext by remember {
        mutableStateOf("High-tension confrontation inside the rain-lashed rooftop sanctuary as secrets unravel.")
    }
    var selectedLanguage by remember { mutableStateOf(language) }
    var emotionalIntensity by remember { mutableStateOf("Intense & Suspenseful") }
    var dialogues by remember { mutableStateOf<List<DialogueLine>>(emptyList()) }
    var isGenerating by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Natural Dialogue Generator",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Generate authentic, high-impact dialogue in Urdu, Hindi, or English with emotion tags and subtext.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = sceneContext,
                        onValueChange = { sceneContext = it },
                        label = { Text("Scene Situation / Conflict Context") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )

                    Text("Dialogue Language:", style = MaterialTheme.typography.titleMedium, color = GoldLight)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppLanguage.values().forEach { lang ->
                            val isSel = selectedLanguage == lang
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedLanguage = lang },
                                label = { Text(lang.displayName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PurpleDark,
                                    selectedLabelColor = GoldAccent
                                )
                            )
                        }
                    }

                    Button(
                        onClick = {
                            isGenerating = true
                            coroutineScope.launch {
                                val result = aiService.generateDialogue(
                                    sceneContext = sceneContext,
                                    characters = characters,
                                    language = selectedLanguage,
                                    intensity = emotionalIntensity
                                )
                                dialogues = result
                                isGenerating = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                        enabled = !isGenerating
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = BgBlack)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Writing Dialogue...", color = BgBlack)
                        } else {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = BgBlack)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate Dialogue", color = BgBlack, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (dialogues.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Dialogue Script",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                    IconButton(onClick = {
                        val fullScript = dialogues.joinToString("\n\n") { line ->
                            val mainText = when (selectedLanguage) {
                                AppLanguage.URDU -> line.textUrdu.ifBlank { line.textEnglish }
                                AppLanguage.HINDI -> line.textHindi.ifBlank { line.textEnglish }
                                else -> line.textEnglish
                            }
                            "${line.speaker} [${line.emotion}]:\n\"$mainText\"\n(Note: ${line.deliveryNote})"
                        }
                        onCopy(fullScript)
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Script", tint = GoldAccent)
                    }
                }
            }

            items(dialogues) { line ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(line.speaker, fontWeight = FontWeight.Bold, color = GoldLight, fontSize = 16.sp)
                                Text("• [${line.emotion}]", color = PurpleLight, fontSize = 12.sp)
                            }
                            IconButton(onClick = {
                                val t = when (selectedLanguage) {
                                    AppLanguage.URDU -> line.textUrdu.ifBlank { line.textEnglish }
                                    AppLanguage.HINDI -> line.textHindi.ifBlank { line.textEnglish }
                                    else -> line.textEnglish
                                }
                                onCopy("${line.speaker} [${line.emotion}]: \"$t\"")
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextSecondary, modifier = Modifier.size(16.dp))
                            }
                        }

                        // Display primary translated line
                        if (selectedLanguage == AppLanguage.URDU && line.textUrdu.isNotBlank()) {
                            Text(
                                text = line.textUrdu,
                                color = TextPrimary,
                                fontSize = 18.sp,
                                lineHeight = 30.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(text = "En: ${line.textEnglish}", color = TextSecondary, fontSize = 12.sp)
                        } else if (selectedLanguage == AppLanguage.HINDI && line.textHindi.isNotBlank()) {
                            Text(
                                text = line.textHindi,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                lineHeight = 24.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(text = "En: ${line.textEnglish}", color = TextSecondary, fontSize = 12.sp)
                        } else {
                            Text(
                                text = line.textEnglish,
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        if (line.deliveryNote.isNotBlank()) {
                            Text(
                                text = "Director note: ${line.deliveryNote}",
                                color = TextMuted,
                                fontSize = 11.sp,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            )
                        }
                    }
                }
            }
        }
    }
}
