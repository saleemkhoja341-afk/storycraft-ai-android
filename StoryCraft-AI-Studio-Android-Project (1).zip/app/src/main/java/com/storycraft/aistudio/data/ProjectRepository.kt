package com.storycraft.aistudio.data

import android.content.Context
import android.content.SharedPreferences
import com.storycraft.aistudio.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

class ProjectRepository(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("storycraft_prefs", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    private val _projects = MutableStateFlow<List<StoryProject>>(emptyList())
    val projects: StateFlow<List<StoryProject>> = _projects.asStateFlow()

    private val _lockedCharacters = MutableStateFlow<List<Character>>(emptyList())
    val lockedCharacters: StateFlow<List<Character>> = _lockedCharacters.asStateFlow()

    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    init {
        loadLanguage()
        loadProjects()
        loadCharacters()
    }

    private fun loadLanguage() {
        val langCode = prefs.getString("key_language", "en") ?: "en"
        val lang = AppLanguage.values().find { it.code == langCode } ?: AppLanguage.ENGLISH
        _currentLanguage.value = lang
    }

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
        prefs.edit().putString("key_language", language.code).apply()
    }

    private fun loadProjects() {
        val savedJson = prefs.getString("key_projects", null)
        if (savedJson.isNullOrBlank()) {
            // Pre-seed with rich sample projects so app is immediately usable
            _projects.value = SampleData.sampleProjects
            saveProjectsToStorage(_projects.value)
        } else {
            try {
                val list = json.decodeFromString<List<StoryProject>>(savedJson)
                _projects.value = list
            } catch (e: Exception) {
                _projects.value = SampleData.sampleProjects
            }
        }
    }

    private fun loadCharacters() {
        val savedJson = prefs.getString("key_characters", null)
        if (savedJson.isNullOrBlank()) {
            _lockedCharacters.value = SampleData.sampleCharacters
            saveCharactersToStorage(_lockedCharacters.value)
        } else {
            try {
                val list = json.decodeFromString<List<Character>>(savedJson)
                _lockedCharacters.value = list
            } catch (e: Exception) {
                _lockedCharacters.value = SampleData.sampleCharacters
            }
        }
    }

    fun saveProject(project: StoryProject) {
        val currentList = _projects.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == project.id }
        if (index >= 0) {
            currentList[index] = project.copy(updatedAt = System.currentTimeMillis())
        } else {
            currentList.add(0, project.copy(updatedAt = System.currentTimeMillis()))
        }
        _projects.value = currentList
        saveProjectsToStorage(currentList)
    }

    fun deleteProject(projectId: String) {
        val updated = _projects.value.filterNot { it.id == projectId }
        _projects.value = updated
        saveProjectsToStorage(updated)
    }

    fun saveCharacter(character: Character) {
        val current = _lockedCharacters.value.toMutableList()
        val idx = current.indexOfFirst { it.id == character.id }
        if (idx >= 0) {
            current[idx] = character
        } else {
            current.add(character)
        }
        _lockedCharacters.value = current
        saveCharactersToStorage(current)
    }

    fun deleteCharacter(characterId: String) {
        val updated = _lockedCharacters.value.filterNot { it.id == characterId }
        _lockedCharacters.value = updated
        saveCharactersToStorage(updated)
    }

    fun resetAllData() {
        prefs.edit().clear().apply()
        _projects.value = SampleData.sampleProjects
        _lockedCharacters.value = SampleData.sampleCharacters
        saveProjectsToStorage(_projects.value)
        saveCharactersToStorage(_lockedCharacters.value)
    }

    private fun saveProjectsToStorage(list: List<StoryProject>) {
        try {
            val encoded = json.encodeToString(list)
            prefs.edit().putString("key_projects", encoded).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun saveCharactersToStorage(list: List<Character>) {
        try {
            val encoded = json.encodeToString(list)
            prefs.edit().putString("key_characters", encoded).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Export stories and prompts as clean plain text
    fun exportProjectAsPlainText(project: StoryProject): String {
        val sb = StringBuilder()
        sb.append("=========================================\n")
        sb.append("STORYCRAFT AI STUDIO - PROJECT EXPORT\n")
        sb.append("Title: ${project.title}\n")
        sb.append("Genre: ${project.genre} | Tone: ${project.tone}\n")
        sb.append("Episodes: ${project.episodes.size} / Target: ${project.targetEpisodes}\n")
        sb.append("Language: ${project.language.displayName}\n")
        sb.append("=========================================\n\n")

        sb.append("--- PREMISE ---\n")
        sb.append("${project.premise}\n\n")

        sb.append("--- LOCKED CHARACTERS (${project.characters.size}) ---\n")
        project.characters.forEachIndexed { i, c ->
            sb.append("${i + 1}. ${c.name} (${c.role}, Age ${c.age})\n")
            sb.append("   Appearance: ${c.appearance}\n")
            sb.append("   Costume/Wardrobe: ${c.clothes}\n")
            sb.append("   Personality: ${c.personality}\n")
            sb.append("   Motivation: ${c.flawAndMotivation}\n\n")
        }

        sb.append("--- EPISODE OUTLINE & SCENES ---\n")
        project.episodes.forEach { ep ->
            sb.append("[Episode ${ep.number}]: ${ep.title}\n")
            sb.append("Logline: ${ep.logline}\n")
            sb.append("Synopsis: ${ep.synopsis}\n")
            sb.append("Key Conflict: ${ep.keyConflict}\n")
            sb.append("Character Arc: ${ep.characterArcs}\n")
            sb.append("Climax: ${ep.climax}\n")
            if (ep.googleFlowPrompt.isNotBlank()) {
                sb.append("Video Prompt: ${ep.googleFlowPrompt}\n")
            }
            sb.append("\n-----------------------------------------\n\n")
        }

        if (project.dialogues.isNotEmpty()) {
            sb.append("--- DIALOGUE EXCERPTS ---\n")
            project.dialogues.forEach { d ->
                sb.append("${d.speaker} [${d.emotion}]:\n")
                if (d.textUrdu.isNotBlank()) sb.append("   Urdu: ${d.textUrdu}\n")
                if (d.textHindi.isNotBlank()) sb.append("   Hindi: ${d.textHindi}\n")
                sb.append("   English: ${d.textEnglish}\n")
                if (d.deliveryNote.isNotBlank()) sb.append("   Note: ${d.deliveryNote}\n")
                sb.append("\n")
            }
        }

        if (project.googleFlowPrompts.isNotEmpty()) {
            sb.append("--- GOOGLE FLOW CINEMATIC VIDEO PROMPTS ---\n")
            project.googleFlowPrompts.forEach { g ->
                sb.append("Scene #${g.sceneNumber}: ${g.title}\n")
                sb.append("Camera: ${g.cameraAngle}\n")
                sb.append("Lighting: ${g.lighting}\n")
                sb.append("Environment: ${g.environment}\n")
                sb.append("Actions: ${g.characterAction}\n")
                sb.append("Audio: ${g.audioAtmosphere}\n")
                sb.append("Prompt: ${g.consolidatedPrompt}\n\n")
            }
        }

        return sb.toString()
    }
}
