package com.storycraft.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.storycraft.aistudio.Screen
import com.storycraft.aistudio.model.Character
import com.storycraft.aistudio.model.StoryProject
import com.storycraft.aistudio.ui.theme.*

@Composable
fun HomeScreen(
    projects: List<StoryProject>,
    characters: List<Character>,
    onNavigateTo: (Screen) -> Unit,
    onCopy: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceElevated)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF2E1065), Color(0xFF150F26), Color(0xFF0A0714))
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = GoldAccent)
                            Text(
                                text = "STORYCRAFT AI STUDIO",
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldAccent,
                                letterSpacing = 2.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Cinematic Multi-Episode Stories & Google Flow Studio",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Craft 5 to 40 episode arcs, lock persistent character appearance & wardrobe across seasons, generate Urdu & Hindi dialogues, and format video prompts for Google Flow.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { onNavigateTo(Screen.GENERATOR) },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
                            ) {
                                Text("New Story", color = BgBlack, fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = { onNavigateTo(Screen.CHARACTERS) }
                            ) {
                                Text("Lock Characters", color = GoldLight)
                            }
                        }
                    }
                }
            }
        }

        // Quick Stats Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickStatCard(
                    title = "Projects",
                    value = projects.size.toString(),
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.Folder
                )
                QuickStatCard(
                    title = "Locked Characters",
                    value = characters.size.toString(),
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.Lock
                )
                QuickStatCard(
                    title = "Max Episodes",
                    value = "40",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.Movie
                )
            }
        }

        // Features Grid
        item {
            Text(
                text = "Creative Modules",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            FeatureNavRow(
                title = "AI Story Generator (5-40 Episodes)",
                desc = "Structure full seasons with episode-by-episode loglines, conflicts, and character arcs.",
                icon = Icons.Default.AutoAwesome,
                onClick = { onNavigateTo(Screen.GENERATOR) }
            )
        }

        item {
            FeatureNavRow(
                title = "Character Lock Studio",
                desc = "Guarantee wardrobe, facial features, age, and voice consistency across all episodes.",
                icon = Icons.Default.Lock,
                onClick = { onNavigateTo(Screen.CHARACTERS) }
            )
        }

        item {
            FeatureNavRow(
                title = "Urdu, Hindi & English Dialogue Generator",
                desc = "Emotional dialogue exchanges with Nastaliq RTL and Devanagari script support.",
                icon = Icons.Default.RecordVoiceOver,
                onClick = { onNavigateTo(Screen.DIALOGUE) }
            )
        }

        item {
            FeatureNavRow(
                title = "Google Flow Video Prompt Studio",
                desc = "Scene-by-scene prompts with camera angles, lighting, environment, and micro-actions.",
                icon = Icons.Default.Videocam,
                onClick = { onNavigateTo(Screen.GOOGLE_FLOW) }
            )
        }

        // Recent Projects Section
        if (projects.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Projects",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    TextButton(onClick = { onNavigateTo(Screen.PROJECTS) }) {
                        Text("View All", color = GoldAccent)
                    }
                }
            }

            items(projects.take(2)) { project ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = project.title,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = GoldLight
                            )
                            IconButton(onClick = { onCopy(project.premise) }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextSecondary)
                            }
                        }
                        Text(
                            text = "${project.genre} • ${project.targetEpisodes} Episodes • ${project.language.displayName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = PurpleLight
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = project.premise,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            maxLines = 2
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuickStatCard(title: String, value: String, modifier: Modifier = Modifier, icon: ImageVector) {
    Card(
        modifier = modifier.clip(RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(20.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(title, style = MaterialTheme.typography.bodyMedium, color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
fun FeatureNavRow(title: String, desc: String, icon: ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PurpleDark),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = GoldAccent)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(desc, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextSecondary)
        }
    }
}
