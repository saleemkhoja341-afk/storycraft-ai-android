package com.storycraft.aistudio.model

import kotlinx.serialization.Serializable

@Serializable
enum class AppLanguage(val code: String, val displayName: String, val isRtl: Boolean) {
    ENGLISH("en", "English", false),
    URDU("ur", "اردو (Urdu)", true),
    HINDI("hi", "हिन्दी (Hindi)", false)
}

@Serializable
data class Character(
    val id: String,
    val name: String,
    val age: Int,
    val role: String, // e.g. "Protagonist", "Antagonist", "Companion", "Mentor"
    val appearance: String, // height, facial structure, skin tone, hair style
    val clothes: String, // signature garments, colors, fabrics, accessories
    val personality: String, // temperament, speech mannerisms, psychology
    val flawAndMotivation: String, // internal struggle & core desire
    val isLocked: Boolean = true // Locked characters are strictly injected into all episodes
)

@Serializable
data class Episode(
    val number: Int,
    val title: String,
    val logline: String,
    val synopsis: String,
    val keyConflict: String,
    val characterArcs: String,
    val climax: String,
    val googleFlowPrompt: String = ""
)

@Serializable
data class DialogueLine(
    val id: String,
    val speaker: String,
    val emotion: String, // e.g. "Furious", "Whispering in fear", "Cold smile"
    val textEnglish: String,
    val textUrdu: String = "",
    val textHindi: String = "",
    val deliveryNote: String = ""
)

@Serializable
data class GoogleFlowPrompt(
    val id: String,
    val sceneNumber: Int,
    val title: String,
    val cameraAngle: String, // e.g. "Low-angle heroic 35mm anamorphic tracking dolly"
    val lighting: String, // e.g. "Chiaroscuro, golden hour backlight with volumetric haze"
    val environment: String, // e.g. "Rain-slicked neon bazaar in futuristic Old City"
    val characterAction: String, // e.g. "Zain adjusts his gold-trimmed shawl while looking into the lens"
    val audioAtmosphere: String, // e.g. "Distant siren, rain patter, muted sitar reverb"
    val consolidatedPrompt: String
)

@Serializable
data class StoryProject(
    val id: String,
    val title: String,
    val genre: String,
    val tone: String,
    val premise: String,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val targetEpisodes: Int = 10, // 5, 10, 20, 30, 40
    val characters: List<Character> = emptyList(),
    val episodes: List<Episode> = emptyList(),
    val dialogues: List<DialogueLine> = emptyList(),
    val googleFlowPrompts: List<GoogleFlowPrompt> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
