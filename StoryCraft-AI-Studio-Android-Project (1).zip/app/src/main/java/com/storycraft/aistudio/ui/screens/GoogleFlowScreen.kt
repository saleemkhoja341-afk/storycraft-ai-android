package com.storycraft.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.storycraft.aistudio.data.ai.GeminiStoryService
import com.storycraft.aistudio.model.*
import com.storycraft.aistudio.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun GoogleFlowScreen(
    characters: List<Character>,
    onCopy: (String) -> Unit,
    aiService: GeminiStoryService
) {
    val coroutineScope = rememberCoroutineScope()

    var sceneTitle by remember { mutableStateOf("Monsoon Infiltration at Midnight") }
    var selectedCamera by remember { mutableStateOf("Low-Angle 35mm Anamorphic Slow Tracking Push") }
    var selectedLighting by remember { mutableStateOf("Volumetric Rain Haze, Cyan Neon Rim-Light, Amber Flares") }
    var environment by remember { mutableStateOf("Ancient stone corridors overlaid with holographic Urdu glyphs and rainfall") }
    var action by remember { mutableStateOf("Draws a concealed dagger while stepping silently onto the glistening marble") }
    var selectedCharIndex by remember { mutableStateOf(0) }

    var generatedPrompt by remember { mutableStateOf<GoogleFlowPrompt?>(null) }
    var promptHistory by remember { mutableStateOf<List<GoogleFlowPrompt>>(emptyList()) }
    var isGenerating by remember { mutableStateOf(false) }

    val cameraPresets = listOf(
        "Low-Angle 35mm Anamorphic Slow Tracking Push",
        "Slow 360-Degree Orbital Dolly at Eye Level",
        "Extreme Close-Up on Eye Reflection, Rapid Pull-Back",
        "High-Speed FPV Drone Tracking Shot into Hallway",
        "Over-the-Shoulder Heroic Static Composition, 50mm f/1.2"
    )

    val lightingPresets = listOf(
        "Volumetric Rain Haze, Cyan Neon Rim-Light, Amber Flares",
        "High-Contrast Chiaroscuro with Flickering Torchlight",
        "Golden Hour Anamorphic Lens Flare, Deep Purple Velvet Shadows",
        "Cold Clinical Bioluminescence, Pulsing Emerald Highlights"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Google Flow Video Prompt Studio",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Craft high-fidelity, scene-by-scene cinematic prompts ready for Google Flow, Veo, Sora, Kling, and Runway.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = sceneTitle,
                        onValueChange = { sceneTitle = it },
                        label = { Text("Scene / Shot Title") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Character Anchor
                    if (characters.isNotEmpty()) {
                        Text("Anchor Character:", style = MaterialTheme.typography.titleMedium, color = GoldLight)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            characters.forEachIndexed { idx, char ->
                                FilterChip(
                                    selected = selectedCharIndex == idx,
                                    onClick = { selectedCharIndex = idx },
                                    label = { Text(char.name) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = PurpleDark,
                                        selectedLabelColor = GoldAccent
                                    )
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = environment,
                        onValueChange = { environment = it },
                        label = { Text("Environment, Architecture & Weather") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = action,
                        onValueChange = { action = it },
                        label = { Text("Character Action & Micro-Expressions") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Camera Angle & Motion:", style = MaterialTheme.typography.titleMedium, color = GoldLight)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        cameraPresets.forEach { preset ->
                            val isSel = selectedCamera == preset
                            Text(
                                text = "• $preset",
                                color = if (isSel) GoldAccent else TextSecondary,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedCamera = preset }
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            isGenerating = true
                            coroutineScope.launch {
                                val char = characters.getOrNull(selectedCharIndex)
                                val result = aiService.generateGoogleFlowPrompt(
                                    sceneTitle = sceneTitle,
                                    environment = environment,
                                    character = char,
                                    action = action,
                                    atmosphere = selectedLighting
                                )
                                generatedPrompt = result
                                promptHistory = listOf(result) + promptHistory
                                isGenerating = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                        enabled = !isGenerating
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null, tint = BgBlack)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Compile Google Flow Prompt", color = BgBlack, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        generatedPrompt?.let { prompt ->
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceElevated)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Compiled Video Prompt",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = GoldLight
                            )
                            Button(
                                onClick = { onCopy(prompt.consolidatedPrompt) },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = BgBlack, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy Prompt", color = BgBlack, fontWeight = FontWeight.Bold)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(BgBlack)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = prompt.consolidatedPrompt,
                                color = TextPrimary,
                                fontSize = 14.sp,
                                lineHeight = 22.sp
                            )
                        }

                        Divider(color = SurfaceBorder)

                        Text("Shot Specifications Breakdown:", color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("Camera: ${prompt.cameraAngle}", color = TextSecondary, fontSize = 12.sp)
                        Text("Lighting: ${prompt.lighting}", color = TextSecondary, fontSize = 12.sp)
                        Text("Action: ${prompt.characterAction}", color = TextSecondary, fontSize = 12.sp)
                        Text("Audio Atmosphere: ${prompt.audioAtmosphere}", color = TextMuted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
